package Project.Main;

import Project.UI.FirstWindow;

import javax.swing.*;

public class Main extends JFrame {

    public static void main(String[] args) {

        FirstWindow program= new FirstWindow("Second lab");
        program.start();
    }
}